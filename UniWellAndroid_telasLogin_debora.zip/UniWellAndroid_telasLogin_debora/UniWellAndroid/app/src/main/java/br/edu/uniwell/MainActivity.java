package br.edu.uniwell;

import android.app.Activity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class MainActivity extends Activity {
    // Demo accounts exist only in memory and disappear when the app process closes.
    private static final Map<String, Account> accountsByEmail = new HashMap<>();
    private FrameLayout cardSlot;
    private TextView title, subtitle;
    private String currentScreen = "login";

    private static final class Account {
        final String name;
        final String email;
        final String password;
        Account(String name, String email, String password) {
            this.name = name;
            this.email = email;
            this.password = password;
        }
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(getColor(R.color.pale));
        getWindow().setNavigationBarColor(getColor(R.color.pale));
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        showLogin();
    }

    private View start(String screen, String heading, String description, int cardLayout) {
        currentScreen = screen;
        setContentView(R.layout.activity_auth);
        title = findViewById(R.id.title);
        subtitle = findViewById(R.id.subtitle);
        cardSlot = findViewById(R.id.card_slot);
        title.setText(heading);
        subtitle.setText(description);
        View card = LayoutInflater.from(this).inflate(cardLayout, cardSlot, false);
        cardSlot.addView(card);
        return card;
    }

    private void showLogin() {
        View card = start("login", "Seu bem-estar em um só lugar.",
                "Acompanhe seus treinos, aulas, hidratação e muito mais.", R.layout.card_login);
        TextView error = card.findViewById(R.id.login_error);
        error.setVisibility(View.GONE);
        EditText identity = card.findViewById(R.id.email);
        EditText password = card.findViewById(R.id.password);
        card.findViewById(R.id.forgot).setOnClickListener(v -> showForgot());
        card.findViewById(R.id.signup).setOnClickListener(v -> showSignup());
        card.findViewById(R.id.primary).setOnClickListener(v -> {
            String email = normalize(identity.getText().toString());
            String enteredPassword = password.getText().toString();
            Account account = accountsByEmail.get(email);
            if (account != null && account.password.equals(enteredPassword)) {
                showLoginSuccess(account);
            } else {
                error.setText("ⓘ  E-mail/usuário ou senha incorretos. Verifique seus dados e tente novamente.");
                error.setVisibility(View.VISIBLE);
            }
        });
    }

    private void showForgot() {
        View card = start("forgot", "Esqueci a senha",
                "Insira o e-mail ou usuário cadastrado para receber as instruções de recuperação da sua senha.", R.layout.card_forgot);
        card.findViewById(R.id.primary).setOnClickListener(v -> showCode());
        card.findViewById(R.id.back).setOnClickListener(v -> showLogin());
    }

    private void showCode() {
        View card = start("code", "Código de recuperação",
                "Enviamos um código para o e-mail ou usuário cadastrado. Digite os 6 dígitos abaixo para continuar a recuperação da sua senha.", R.layout.card_code);
        card.findViewById(R.id.primary).setOnClickListener(v -> showNewPassword());
        card.findViewById(R.id.resend).setOnClickListener(v -> Toast.makeText(this, "Código reenviado.", Toast.LENGTH_SHORT).show());
        card.findViewById(R.id.back).setOnClickListener(v -> showForgot());
    }

    private void showNewPassword() {
        View card = start("new_password", "Nova senha",
                "Crie uma senha forte e segura para garantir a proteção e o acesso à sua conta UniWell.", R.layout.card_new_password);
        EditText password = card.findViewById(R.id.password);
        EditText confirm = card.findViewById(R.id.confirm);
        card.findViewById(R.id.primary).setOnClickListener(v -> {
            if (TextUtils.isEmpty(password.getText()) || !password.getText().toString().equals(confirm.getText().toString())) {
                Toast.makeText(this, "As senhas não coincidem.", Toast.LENGTH_SHORT).show();
                return;
            }
            Toast.makeText(this, "Senha redefinida.", Toast.LENGTH_SHORT).show();
            showLogin();
        });
        card.findViewById(R.id.back).setOnClickListener(v -> showLogin());
    }

    private void showSignup() {
        View card = start("signup", "Crie sua conta",
                "Insira seus dados pessoais abaixo para começar sua jornada de bem-estar na UNIFOR.", R.layout.card_signup);
        EditText name = card.findViewById(R.id.name);
        EditText email = card.findViewById(R.id.email);
        EditText password = card.findViewById(R.id.password);
        EditText confirm = card.findViewById(R.id.confirm);
        TextView emailError = card.findViewById(R.id.email_error);
        TextView passwordError = card.findViewById(R.id.password_error);
        emailError.setVisibility(View.GONE);
        passwordError.setVisibility(View.GONE);
        card.findViewById(R.id.back).setOnClickListener(v -> showLogin());
        card.findViewById(R.id.primary).setOnClickListener(v -> {
            String fullName = name.getText().toString().trim();
            String mail = normalize(email.getText().toString());
            String pass = password.getText().toString();
            boolean validEmail = Patterns.EMAIL_ADDRESS.matcher(mail).matches();
            boolean validPassword = !TextUtils.isEmpty(pass) && pass.equals(confirm.getText().toString());

            if (accountsByEmail.containsKey(mail)) {
                emailError.setText("ⓘ  Este e-mail já está cadastrado. Use outro e-mail ou faça login.");
                emailError.setVisibility(View.VISIBLE);
                passwordError.setVisibility(View.GONE);
                return;
            }
            if (!validEmail) {
                emailError.setText("ⓘ  E-mail inválido. Verifique o formato e tente novamente.");
                emailError.setVisibility(View.VISIBLE);
            } else {
                emailError.setVisibility(View.GONE);
            }
            if (!validPassword) {
                passwordError.setText("ⓘ  As senhas não coincidem ou estão vazias.");
                passwordError.setVisibility(View.VISIBLE);
            } else {
                passwordError.setVisibility(View.GONE);
            }
            if (TextUtils.isEmpty(fullName) || !validEmail || !validPassword) return;

            accountsByEmail.put(mail, new Account(fullName, mail, pass));
            showComplete();
        });
    }

    private void showComplete() {
        View card = start("complete", "", "", R.layout.card_complete);
        card.findViewById(R.id.primary).setOnClickListener(v -> showLogin());
    }

    private void showLoginSuccess(Account account) {
        View card = start("login_success", "Login confirmado", "Acesso realizado com sucesso.", R.layout.card_login_success);
        TextView welcome = card.findViewById(R.id.welcome);
        welcome.setText("Olá, " + account.name + "! Seu login foi confirmado com sucesso.");
        card.findViewById(R.id.primary).setOnClickListener(v -> showLogin());
    }

    private String normalize(String value) {
        return value == null ? "" : value.trim().toLowerCase(Locale.ROOT);
    }

    @Override public void onBackPressed() {
        if (!"login".equals(currentScreen)) showLogin();
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (isFinishing() && !isChangingConfigurations()) accountsByEmail.clear();
        super.onDestroy();
    }
}
