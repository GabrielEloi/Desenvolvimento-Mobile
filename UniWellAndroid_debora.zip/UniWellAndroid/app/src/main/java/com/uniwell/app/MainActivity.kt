package com.uniwell.app

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Teal = Color(0xFF126F65)
private val DeepTeal = Color(0xFF17443F)
private val Lime = Color(0xFFC8EA83)
private val PaleLime = Color(0xFFF0F8DE)
private val Background = Color(0xFFF4F7F6)
private val Muted = Color(0xFF84918E)
private val Border = Color(0xFFE3EAE7)
private val ErrorRed = Color(0xFFB85F5F)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = lightColorScheme(primary = Teal, background = Background)) { UniWellApp() } }
    }
}

private enum class Screen { LOGIN, LOGIN_ERROR, FORGOT, RESET, REGISTER, HOME }

@Composable
private fun UniWellApp() {
    var screen by remember { mutableStateOf(Screen.LOGIN) }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var fullName by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var recoverySent by remember { mutableStateOf(false) }
    var resetDone by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }

    Box(Modifier.fillMaxSize().background(Background)) {
        // Decorative background shapes match the reference screens.
        Box(Modifier.align(Alignment.TopEnd).offset(x = 78.dp, y = (-42).dp).size(205.dp).clip(CircleShape).background(PaleLime))
        Box(Modifier.align(Alignment.BottomStart).offset(x = (-105).dp, y = 70.dp).size(235.dp).clip(CircleShape).background(Color(0xFFECF6EF)))
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 24.dp)) {
            if (screen == Screen.RESET) {
                IconButtonBack { screen = Screen.FORGOT }
                Spacer(Modifier.height(10.dp))
                BrandHeader(showTagline = false, title = "Nova senha", subtitle = "Crie uma senha forte e segura para garantir a proteção e o acesso à sua conta UniWell.")
            } else if (screen == Screen.FORGOT) {
                Spacer(Modifier.height(34.dp))
                BrandHeader(showTagline = false, title = "Esqueci a senha", subtitle = "Insira o e-mail ou usuário cadastrado para receber as instruções de recuperação da senha.")
            } else if (screen == Screen.REGISTER) {
                Spacer(Modifier.height(22.dp))
                BrandWordmark()
                Spacer(Modifier.height(16.dp))
                Text("Crie sua conta", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = DeepTeal, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                Text("Insira seus dados pessoais abaixo para começar sua jornada de bem-estar na UNIFOR.", fontSize = 12.sp, lineHeight = 17.sp, color = Muted, textAlign = TextAlign.Center)
            } else {
                Spacer(Modifier.height(34.dp))
                BrandHeader(showTagline = true, title = "Seu bem-estar em um só lugar.", subtitle = "Acompanhe seus treinos, aulas, hidratação e muito mais.")
            }
            Spacer(Modifier.height(if (screen == Screen.FORGOT) 126.dp else if (screen == Screen.RESET) 78.dp else if (screen == Screen.REGISTER) 18.dp else 48.dp))

            when (screen) {
                Screen.LOGIN, Screen.LOGIN_ERROR -> {
                    FormCard {
                        FieldLabel("E-mail ou usuário")
                        InputField(email, { email = it; message = "" }, "Digite seu e-mail ou usuário", Icons.Default.Email, KeyboardType.Email)
                        Spacer(Modifier.height(14.dp))
                        FieldLabel("Senha")
                        PasswordField(password, { password = it; message = "" }, "Digite sua senha")
                        if (message.isNotBlank() && screen == Screen.LOGIN) {
                            Spacer(Modifier.height(8.dp))
                            ErrorText(message)
                        }
                        if (screen == Screen.LOGIN_ERROR) {
                            Spacer(Modifier.height(12.dp))
                            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Color(0xFFFFF1F0)).padding(12.dp), verticalAlignment = Alignment.Top) {
                                Icon(Icons.Default.ErrorOutline, null, tint = ErrorRed, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(8.dp))
                                Text("E-mail/usuário ou senha incorretos. Verifique seus dados e tente novamente.", fontSize = 11.sp, lineHeight = 15.sp, color = ErrorRed)
                            }
                        }
                        Text("Esqueceu sua senha?", color = Teal, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.align(Alignment.End).padding(top = 14.dp, bottom = 18.dp).clickable { screen = Screen.FORGOT })
                        PrimaryButton("Login") {
                            if (email.isBlank() || password.isBlank()) {
                                message = "Preencha o e-mail/usuário e a senha."
                            } else if (email.contains("@") && password.length >= 6) {
                                screen = Screen.HOME
                            } else screen = Screen.LOGIN_ERROR
                        }
                        Spacer(Modifier.height(14.dp))
                        CenterLink("Ainda não possui uma conta? ", "Cadastre-se") { screen = Screen.REGISTER }
                    }
                }
                Screen.FORGOT -> {
                    FormCard {
                        FieldLabel("E-mail ou usuário")
                        InputField(email, { email = it; message = "" }, "Digite seu e-mail ou usuário", Icons.Default.Email, KeyboardType.Email)
                        Spacer(Modifier.height(18.dp))
                        PrimaryButton("Recuperar Senha") {
                            if (email.isBlank()) message = "Informe seu e-mail ou usuário."
                            else { recoverySent = true; message = "Se a conta existir, as instruções de recuperação serão enviadas." }
                        }
                        if (recoverySent) {
                            Spacer(Modifier.height(12.dp))
                            Text(message, color = Teal, fontSize = 12.sp, textAlign = TextAlign.Center)
                            Text("Continuar para redefinir senha (demonstração)", color = Teal, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.align(Alignment.CenterHorizontally).padding(top = 10.dp).clickable { screen = Screen.RESET })
                        } else if (message.isNotBlank()) ErrorText(message)
                        Spacer(Modifier.height(14.dp))
                        CenterLink("Lembrou sua senha? ", "Voltar para o login") { screen = Screen.LOGIN; message = "" }
                    }
                }
                Screen.RESET -> {
                    FormCard {
                        FieldLabel("Nova senha")
                        PasswordField(password, { password = it }, "Crie uma senha forte")
                        Spacer(Modifier.height(14.dp))
                        FieldLabel("Confirmar nova senha")
                        PasswordField(confirmPassword, { confirmPassword = it }, "Repita a nova senha")
                        Spacer(Modifier.height(18.dp))
                        PrimaryButton("Redefinir senha") {
                            when {
                                password.length < 6 -> message = "A senha deve ter pelo menos 6 caracteres."
                                password != confirmPassword -> message = "As senhas não coincidem."
                                else -> { resetDone = true; message = "Senha redefinida nesta demonstração." }
                            }
                        }
                        if (message.isNotBlank()) Text(message, color = if (resetDone) Teal else ErrorRed, fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp))
                        Spacer(Modifier.height(12.dp))
                        CenterLink("", "Voltar para o login") { screen = Screen.LOGIN; message = ""; password = ""; confirmPassword = "" }
                    }
                }
                Screen.REGISTER -> {
                    FormCard {
                        FieldLabel("Nome completo")
                        InputField(fullName, { fullName = it }, "Digite seu nome completo", Icons.Default.Person, KeyboardType.Text)
                        Spacer(Modifier.height(14.dp))
                        FieldLabel("E-mail")
                        InputField(email, { email = it }, "Digite seu e-mail", Icons.Default.Email, KeyboardType.Email)
                        Spacer(Modifier.height(14.dp))
                        FieldLabel("Senha")
                        PasswordField(password, { password = it }, "Crie uma senha forte")
                        Spacer(Modifier.height(14.dp))
                        FieldLabel("Confirmar senha")
                        PasswordField(confirmPassword, { confirmPassword = it }, "Repita a senha criada")
                        Spacer(Modifier.height(18.dp))
                        PrimaryButton("Cadastrar") {
                            message = when {
                                fullName.isBlank() -> "Informe seu nome completo."
                                !email.contains("@") -> "Informe um e-mail válido."
                                password.length < 6 -> "A senha deve ter pelo menos 6 caracteres."
                                password != confirmPassword -> "As senhas não coincidem."
                                else -> ""
                            }
                            if (message.isBlank()) screen = Screen.HOME
                        }
                        if (message.isNotBlank()) ErrorText(message)
                        Spacer(Modifier.height(14.dp))
                        CenterLink("Já possui uma conta? ", "Fazer login") { screen = Screen.LOGIN; message = "" }
                    }
                }
                Screen.HOME -> {
                    FormCard {
                        Icon(Icons.Default.CheckCircle, null, tint = Teal, modifier = Modifier.size(44.dp).align(Alignment.CenterHorizontally))
                        Spacer(Modifier.height(12.dp))
                        Text("Bem-vinda ao UniWell!", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = DeepTeal, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                        Spacer(Modifier.height(8.dp))
                        Text("Sua área inicial está pronta para receber os módulos de treinos, aulas e hidratação.", color = Muted, textAlign = TextAlign.Center, fontSize = 13.sp)
                        Spacer(Modifier.height(18.dp))
                        PrimaryButton("Sair da conta") { screen = Screen.LOGIN; password = ""; message = "" }
                    }
                }
            }
            Spacer(Modifier.height(26.dp))
            Footer()
            Spacer(Modifier.height(18.dp))
        }
    }
}

@Composable private fun BrandHeader(showTagline: Boolean, title: String, subtitle: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
        LogoMark()
        Spacer(Modifier.height(8.dp))
        Text("UniWell", fontSize = 27.sp, fontWeight = FontWeight.ExtraBold, color = DeepTeal)
        Spacer(Modifier.height(12.dp))
        Text(title, fontSize = 21.sp, lineHeight = 25.sp, fontWeight = FontWeight.Bold, color = Color(0xFF142E2B), textAlign = TextAlign.Center)
        Spacer(Modifier.height(10.dp))
        Text(subtitle, fontSize = 12.sp, lineHeight = 17.sp, color = Muted, textAlign = TextAlign.Center, modifier = Modifier.padding(horizontal = 4.dp))
    }
}
@Composable private fun BrandWordmark() {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center, modifier = Modifier.fillMaxWidth()) {
        LogoMark(42)
        Spacer(Modifier.width(8.dp))
        Text("UniWell", fontSize = 25.sp, fontWeight = FontWeight.ExtraBold, color = DeepTeal)
    }
}
@Composable private fun LogoMark(size: Int = 54) {
    Box(Modifier.size(size.dp).clip(RoundedCornerShape(14.dp)).background(Teal), contentAlignment = Alignment.Center) {
        Text("U", color = Color.White, fontSize = (size * .56).sp, fontWeight = FontWeight.ExtraBold)
        Box(Modifier.align(Alignment.TopEnd).size((size * .42).dp).clip(CircleShape).background(Lime))
        Box(Modifier.align(Alignment.BottomEnd).padding(5.dp).size(5.dp).clip(CircleShape).background(Lime))
    }
}
@Composable private fun FormCard(content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(Color.White).padding(18.dp), content = content)
}
@Composable private fun FieldLabel(text: String) {
    Text(text, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF243C38), modifier = Modifier.padding(bottom = 7.dp))
}
@Composable private fun InputField(value: String, onValueChange: (String) -> Unit, placeholder: String, icon: androidx.compose.ui.graphics.vector.ImageVector, keyboard: KeyboardType) {
    OutlinedTextField(value = value, onValueChange = onValueChange, placeholder = { Text(placeholder, color = Muted, fontSize = 12.sp) }, leadingIcon = { Icon(icon, null, tint = Teal, modifier = Modifier.size(18.dp)) }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = keyboard), shape = RoundedCornerShape(12.dp), colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Teal, unfocusedBorderColor = Border, focusedContainerColor = Color(0xFFF7F9F8), unfocusedContainerColor = Color(0xFFF7F9F8)), modifier = Modifier.fillMaxWidth().height(54.dp), textStyle = androidx.compose.ui.text.TextStyle(fontSize = 13.sp))
}
@Composable private fun PasswordField(value: String, onValueChange: (String) -> Unit, placeholder: String) {
    var visible by remember { mutableStateOf(false) }
    OutlinedTextField(value = value, onValueChange = onValueChange, placeholder = { Text(placeholder, color = Muted, fontSize = 12.sp) }, leadingIcon = { Icon(Icons.Default.Lock, null, tint = Teal, modifier = Modifier.size(18.dp)) }, trailingIcon = { IconButton(onClick = { visible = !visible }) { Icon(if (visible) Icons.Default.VisibilityOff else Icons.Default.Visibility, null, tint = Muted, modifier = Modifier.size(18.dp)) } }, singleLine = true, visualTransformation = if (visible) VisualTransformation.None else PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password), shape = RoundedCornerShape(12.dp), colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Teal, unfocusedBorderColor = Border, focusedContainerColor = Color(0xFFF7F9F8), unfocusedContainerColor = Color(0xFFF7F9F8)), modifier = Modifier.fillMaxWidth().height(54.dp), textStyle = androidx.compose.ui.text.TextStyle(fontSize = 13.sp))
}
@Composable private fun PrimaryButton(text: String, onClick: () -> Unit) {
    Button(onClick = onClick, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(12.dp), colors = ButtonDefaults.buttonColors(containerColor = Teal, contentColor = Color.White), elevation = ButtonDefaults.buttonElevation(defaultElevation = 3.dp)) {
        Text(text, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.width(10.dp))
        Icon(Icons.AutoMirrored.Filled.ArrowForward, null, modifier = Modifier.size(17.dp))
    }
}
@Composable private fun CenterLink(prefix: String, link: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
        Text(prefix, fontSize = 11.sp, color = Muted)
        Text(link, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Teal, modifier = Modifier.clickable { onClick() })
    }
}
@Composable private fun ErrorText(text: String) {
    Text(text, color = ErrorRed, fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp))
}
@Composable private fun Footer() {
    Row(horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
        Box(Modifier.size(6.dp).clip(CircleShape).background(Lime))
        Spacer(Modifier.width(5.dp))
        Text("Academia UNIFOR • UniWell", fontSize = 10.sp, color = Muted)
    }
}
@Composable private fun IconButtonBack(onClick: () -> Unit) {
    IconButton(onClick = onClick, modifier = Modifier.padding(top = 8.dp)) {
        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Voltar", tint = DeepTeal)
    }
}
