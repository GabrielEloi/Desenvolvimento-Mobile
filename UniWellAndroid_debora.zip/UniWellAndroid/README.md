# UniWell — Android Studio (Kotlin + Jetpack Compose)

Projeto inicial com as cinco telas de referência: Login, Login com erro, Esqueci a senha, Nova senha e Cadastro. A navegação, validações de formulário, alternância de visibilidade da senha e tela inicial de demonstração estão implementadas.

## Abrir no Android Studio
1. Extraia `UniWellAndroid.zip`.
2. Abra o Android Studio e selecione **Open**; escolha a pasta `UniWellAndroid` (a pasta que contém `settings.gradle.kts`).
3. Aguarde o Gradle Sync. Se o Android Studio sugerir instalar SDK 35, aceite; use JDK 17.
4. Crie/abra um emulador em Device Manager ou conecte um Android com depuração USB.
5. Clique em **Run ▶**.

## Como testar
- Login: informe um e-mail contendo `@` e uma senha de pelo menos 6 caracteres para entrar na tela inicial de demonstração.
- Login com erro: informe dados inválidos ou senha curta.
- Cadastro: nome, e-mail válido, senha com pelo menos 6 caracteres e confirmação igual.
- Esqueci a senha: informe um e-mail/usuário; a recuperação é simulada e aparece um atalho para a tela de nova senha.
- Nova senha: valide o tamanho e a confirmação.

## Importante
Este projeto é uma implementação visual e funcional local para prototipagem. Login/cadastro não estão conectados a servidor ou banco de dados, e a recuperação não envia e-mail real. Para produção, conecte Firebase Authentication ou uma API própria; nunca armazene senhas em texto puro. O layout foi reconstruído a partir das imagens fornecidas; diferenças pequenas podem ocorrer por fonte, densidade e barras do dispositivo.
