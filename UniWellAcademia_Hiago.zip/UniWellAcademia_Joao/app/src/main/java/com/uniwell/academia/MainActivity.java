package com.uniwell.academia;

import android.app.Activity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class MainActivity extends Activity {
    // Demo accounts exist only in memory and disappear when the app process closes.
    private static final Map<String, Account> accountsByEmail = new HashMap<>();
    private FrameLayout cardSlot;
    private TextView title, subtitle;
    private String currentScreen = "login";

    private static final class Account {
        final String name;
        final String email;
        final String password;
        Account(String name, String email, String password) {
            this.name = name;
            this.email = email;
            this.password = password;
        }
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(getColor(R.color.pale));
        getWindow().setNavigationBarColor(getColor(R.color.pale));
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        showLogin();
    }

    private View start(String screen, String heading, String description, int cardLayout) {
        currentScreen = screen;
        setContentView(R.layout.activity_auth);
        title = findViewById(R.id.title);
        subtitle = findViewById(R.id.subtitle);
        cardSlot = findViewById(R.id.card_slot);
        title.setText(heading);
        subtitle.setText(description);
        View card = LayoutInflater.from(this).inflate(cardLayout, cardSlot, false);
        cardSlot.addView(card);
        return card;
    }

    private void showLogin() {
        View card = start("login", "Seu bem-estar em um só lugar.",
                "Acompanhe seus treinos, aulas, hidratação e muito mais.", R.layout.card_login);
        TextView error = card.findViewById(R.id.login_error);
        error.setVisibility(View.GONE);
        EditText identity = card.findViewById(R.id.email);
        EditText password = card.findViewById(R.id.password);
        setFieldIcon(identity, R.drawable.ic_mail);
        setFieldIcon(password, R.drawable.ic_lock);
        card.findViewById(R.id.forgot).setOnClickListener(v -> showForgot());
        card.findViewById(R.id.signup).setOnClickListener(v -> showSignup());
        card.findViewById(R.id.primary).setOnClickListener(v -> {
            String email = normalize(identity.getText().toString());
            String enteredPassword = password.getText().toString();
            Account account = accountsByEmail.get(email);
            if (account != null && account.password.equals(enteredPassword)) {
                showLoginSuccess(account);
            } else {
                error.setText("ⓘ  E-mail/usuário ou senha incorretos. Verifique seus dados e tente novamente.");
                error.setVisibility(View.VISIBLE);
            }
        });
    }

    private void showForgot() {
        View card = start("forgot", "Esqueci a senha",
                "Insira o e-mail ou usuário cadastrado para receber as instruções de recuperação da sua senha.", R.layout.card_forgot);
        setFieldIcon(card.findViewById(R.id.email), R.drawable.ic_mail);
        card.findViewById(R.id.primary).setOnClickListener(v -> showCode());
        card.findViewById(R.id.back).setOnClickListener(v -> showLogin());
    }

    private void showCode() {
        View card = start("code", "Código de recuperação",
                "Enviamos um código para o e-mail ou usuário cadastrado. Digite os 6 dígitos abaixo para continuar a recuperação da sua senha.", R.layout.card_code);
        card.findViewById(R.id.primary).setOnClickListener(v -> showNewPassword());
        card.findViewById(R.id.resend).setOnClickListener(v -> Toast.makeText(this, "Código reenviado.", Toast.LENGTH_SHORT).show());
        card.findViewById(R.id.back).setOnClickListener(v -> showForgot());
    }

    private void showNewPassword() {
        View card = start("new_password", "Nova senha",
                "Crie uma senha forte e segura para garantir a proteção e o acesso à sua conta UniWell.", R.layout.card_new_password);
        EditText password = card.findViewById(R.id.password);
        EditText confirm = card.findViewById(R.id.confirm);
        setFieldIcon(password, R.drawable.ic_lock);
        setFieldIcon(confirm, R.drawable.ic_lock);
        card.findViewById(R.id.primary).setOnClickListener(v -> {
            if (TextUtils.isEmpty(password.getText()) || !password.getText().toString().equals(confirm.getText().toString())) {
                Toast.makeText(this, "As senhas não coincidem.", Toast.LENGTH_SHORT).show();
                return;
            }
            Toast.makeText(this, "Senha redefinida.", Toast.LENGTH_SHORT).show();
            showLogin();
        });
        card.findViewById(R.id.back).setOnClickListener(v -> showLogin());
    }

    private void showSignup() {
        View card = start("signup", "Crie sua conta",
                "Insira seus dados pessoais abaixo para começar sua jornada de bem-estar na UNIFOR.", R.layout.card_signup);
        EditText name = card.findViewById(R.id.name);
        EditText email = card.findViewById(R.id.email);
        EditText password = card.findViewById(R.id.password);
        EditText confirm = card.findViewById(R.id.confirm);
        setFieldIcon(name, R.drawable.ic_person);
        setFieldIcon(email, R.drawable.ic_mail);
        setFieldIcon(password, R.drawable.ic_lock);
        setFieldIcon(confirm, R.drawable.ic_lock);
        TextView emailError = card.findViewById(R.id.email_error);
        TextView passwordError = card.findViewById(R.id.password_error);
        emailError.setVisibility(View.GONE);
        passwordError.setVisibility(View.GONE);
        card.findViewById(R.id.back).setOnClickListener(v -> showLogin());
        card.findViewById(R.id.primary).setOnClickListener(v -> {
            String fullName = name.getText().toString().trim();
            String mail = normalize(email.getText().toString());
            String pass = password.getText().toString();
            boolean validEmail = Patterns.EMAIL_ADDRESS.matcher(mail).matches();
            boolean validPassword = !TextUtils.isEmpty(pass) && pass.equals(confirm.getText().toString());

            if (accountsByEmail.containsKey(mail)) {
                emailError.setText("ⓘ  Este e-mail já está cadastrado. Use outro e-mail ou faça login.");
                emailError.setVisibility(View.VISIBLE);
                passwordError.setVisibility(View.GONE);
                return;
            }
            if (!validEmail) {
                emailError.setText("ⓘ  E-mail inválido. Verifique o formato e tente novamente.");
                emailError.setVisibility(View.VISIBLE);
            } else {
                emailError.setVisibility(View.GONE);
            }
            if (!validPassword) {
                passwordError.setText("ⓘ  As senhas não coincidem ou estão vazias.");
                passwordError.setVisibility(View.VISIBLE);
            } else {
                passwordError.setVisibility(View.GONE);
            }
            if (TextUtils.isEmpty(fullName) || !validEmail || !validPassword) return;

            accountsByEmail.put(mail, new Account(fullName, mail, pass));
            showComplete();
        });
    }

    private void showComplete() {
        View card = start("complete", "", "", R.layout.card_complete);
        card.findViewById(R.id.primary).setOnClickListener(v -> showLogin());
    }

        private void showLoginSuccess(Account account) {
        View card = start("login_success", "Login confirmado", "Acesso realizado com sucesso.", R.layout.card_login_success);
        TextView welcome = card.findViewById(R.id.welcome);
        welcome.setText("Login confirmado com sucesso. Seu acesso ao UniWell está ativo.");
        card.findViewById(R.id.primary).setOnClickListener(v -> showHome());
    }

    private void setFieldIcon(EditText field, int drawableId) {
        field.setCompoundDrawablesWithIntrinsicBounds(getDrawable(drawableId), null, null, null);
        field.setCompoundDrawablePadding(8);
    }
    private void showHome() {
        currentScreen = "home";
        setContentView(R.layout.screen_home);
        bind(R.id.btn_notifications, this::showNotifications);
        bind(R.id.btn_workout, () -> showPage("workouts"));
        bind(R.id.btn_hydration, () -> showPage("water"));
        bind(R.id.btn_agenda, () -> showPage("classes"));
        bind(R.id.nav_home, this::showHome);
        bind(R.id.nav_agenda, () -> showPage("classes"));
        bind(R.id.nav_workouts, () -> showPage("workouts"));
        bind(R.id.nav_hydration, () -> showPage("water"));
        bind(R.id.nav_profile, () -> showPage("profile"));
    }

    private void showNotifications() {
        currentScreen = "notifications";
        setContentView(R.layout.screen_notifications);
        bind(R.id.notification_training, this::showTrainingDetail);
        bind(R.id.notification_maintenance, this::showMaintenance);
        bind(R.id.nav_home, this::showHome);
        bind(R.id.nav_agenda, () -> showPage("classes"));
        bind(R.id.nav_workouts, () -> showPage("workouts"));
        bind(R.id.nav_hydration, () -> showPage("water"));
        bind(R.id.nav_profile, () -> showPage("profile"));
    }

    private void showTrainingDetail() {
        currentScreen = "notification_detail";
        setContentView(R.layout.screen_notification_detail);
        bind(R.id.btn_back_notifications, this::showNotifications);
        bind(R.id.nav_home, this::showHome);
        bind(R.id.nav_agenda, () -> showPage("classes"));
        bind(R.id.nav_workouts, () -> showPage("workouts"));
        bind(R.id.nav_hydration, () -> showPage("water"));
        bind(R.id.nav_profile, () -> showPage("profile"));
    }

    private void showMaintenance() {
        currentScreen = "maintenance";
        setContentView(R.layout.screen_maintenance_notice);
        bind(R.id.btn_back_home, this::showNotifications);
        bind(R.id.btn_acknowledge, this::showHome);
        bind(R.id.nav_home, this::showHome);
        bind(R.id.nav_agenda, () -> showPage("classes"));
        bind(R.id.nav_workouts, () -> showPage("workouts"));
        bind(R.id.nav_hydration, () -> showPage("water"));
        bind(R.id.nav_profile, () -> showPage("profile"));
    }

    private int waterMl = 1600;
    private int selectedWorkout = 0;
    private int exerciseIndex = 0;
    private int seriesIndex = 0;
    private int waterAddAmount = 500;
    private boolean remindersOn = true;
    private String profileName = "Maria Silva";
    private String selectedClass = "Pilates";
    private String profileEmail = "maria.silva@unifor.br";
    private String[][] exercises = {
        {"Supino Reto", "Desenvolvimento Halteres", "Tríceps Corda", "Elevação Lateral"},
        {"Puxada Alta", "Remada Curvada", "Rosca Direta W", "Abdominal Infra"},
        {"Agachamento Livre", "Leg Press 45°", "Cadeira Extensora", "Mesa Flexora"},
        {"Esteira", "Prancha", "Abdominal Remador", "Polichinelos"}
    };
    private int exerciseSets(int workout, int index) { int[][] sets={{4,4,3,3},{4,4,3,3},{4,4,3,3},{1,3,3,3}}; return sets[workout][index]; }
    private int exerciseReps(int workout, int index) { int[][] reps={{10,12,15,12},{10,12,12,20},{10,12,15,12},{1,1,20,1}}; return reps[workout][index]; }

    private void showModule(String page) {
        currentScreen = page;
        setContentView(R.layout.screen_module);
        TextView heading = findViewById(R.id.module_title);
        int layout = page.startsWith("water") ? R.layout.screen_water :
                page.startsWith("workout") ? R.layout.screen_workouts :
                page.startsWith("class") || page.equals("my_classes") ? R.layout.screen_classes : R.layout.screen_profile;
        int groupId = groupFor(page);
        View screenRoot = LayoutInflater.from(this).inflate(layout, (FrameLayout) null);
        View active = screenRoot.findViewById(groupId);
        if (active != null) active.setVisibility(View.VISIBLE);
        // Keep the scroll container and install the selected XML screen group inside it.
        android.widget.LinearLayout body = findViewById(R.id.module_content);
        body.removeAllViews();
        if (active != null) {
            ((android.view.ViewGroup) active.getParent()).removeView(active);
            body.addView(active);
        }
        heading.setText(titleFor(page));
        bind(R.id.module_back, () -> onBackPressed());
        bind(R.id.nav_home, this::showHome);
        bind(R.id.nav_agenda, () -> showPage("classes"));
        bind(R.id.nav_workouts, () -> showPage("workouts"));
        bind(R.id.nav_hydration, () -> showPage("water"));
        bind(R.id.nav_profile, () -> showPage("profile"));
        bindActive(active, page);
        highlightNavigation(page);
    }

    private int groupFor(String page) {
        switch (page) {
            case "water": return R.id.group_water_home;
            case "water_add": return R.id.group_water_add;
            case "water_history": return R.id.group_water_history;
            case "water_reminders": return R.id.group_water_reminders;
            case "water_goal": return R.id.group_water_goal;
            case "workouts": return R.id.group_workout_list;
            case "workout_detail": return R.id.group_workout_detail;
            case "workout_run": return R.id.group_workout_execution;
            case "workout_done": return R.id.group_workout_done;
            case "classes": return R.id.group_classes_home;
            case "class_list": return R.id.group_class_list;
            case "class_detail": return R.id.group_class_detail;
            case "class_confirm": return R.id.group_class_confirm;
            case "class_full": return R.id.group_class_full;
            case "my_classes": return R.id.group_my_classes;
            case "class_enrollment": return R.id.group_enrollment_detail;
            case "profile": return R.id.group_profile;
            case "personal": return R.id.group_personal;
            case "edit_personal": return R.id.group_edit_personal;
            case "settings": return R.id.group_settings;
            case "privacy": return R.id.group_privacy;
            default: return R.id.group_about;
        }
    }

    private String titleFor(String page) {
        if (page.equals("water")) return "Hidratação";
        if (page.equals("water_add")) return "Registrar água";
        if (page.equals("water_history")) return "Histórico de hidratação";
        if (page.equals("water_reminders")) return "Lembretes de hidratação";
        if (page.equals("water_goal")) return "Meta de hidratação";
        if (page.equals("workouts")) return "Ficha de Treino";
        if (page.startsWith("workout")) return page.equals("workout_done") ? "Treino Concluído" : "Treino " + "ABCD".charAt(selectedWorkout);
        if (page.equals("classes")) return "Aulas";
        if (page.equals("class_list")) return "Lista de aulas";
        if (page.equals("class_detail")) return "Detalhes da aula";
        if (page.equals("class_confirm")) return "Inscrição confirmada";
        if (page.equals("class_full")) return "Aula lotada";
        if (page.equals("my_classes")) return "Minhas inscrições";
        if (page.equals("class_enrollment")) return "Detalhes da inscrição";
        if (page.equals("profile")) return "Perfil";
        if (page.equals("personal")) return "Dados pessoais";
        if (page.equals("edit_personal")) return "Editar dados";
        if (page.equals("settings")) return "Configurações";
        if (page.equals("privacy")) return "Privacidade";
        return "Sobre o app";
    }

    private void bindActive(View root, String page) {
        if (root == null) return;
        if (page.equals("water")) {
            bindIn(root, R.id.btn_add, () -> showPage("water_add"));
            bindIn(root, R.id.btn_history, () -> showPage("water_history"));
            bindIn(root, R.id.btn_reminders, () -> showPage("water_reminders"));
            TextView amount = root.findViewById(R.id.water_amount);
            TextView remaining = root.findViewById(R.id.water_remaining);
            if (amount != null) amount.setText(String.format(Locale.forLanguageTag("pt-BR"), "%.1f L", waterMl / 1000f));
            if (remaining != null) remaining.setText(Math.min(100, waterMl * 100 / 2500) + "% da meta diária       Faltam " + Math.max(0, 2500 - waterMl) + " ml");
            android.widget.ProgressBar progress = root.findViewById(R.id.water_progress); if (progress != null) progress.setProgress(waterMl);
        } else if (page.equals("water_add")) {
            TextView amount = root.findViewById(R.id.amount_label); if (amount != null) amount.setText(waterAddAmount + " ml");
            bindIn(root, R.id.preset_200, () -> {waterAddAmount=200;showPage("water_add");});
            bindIn(root, R.id.preset_300, () -> {waterAddAmount=300;showPage("water_add");});
            bindIn(root, R.id.preset_500, () -> {waterAddAmount=500;showPage("water_add");});
            bindIn(root, R.id.amount_minus, () -> {waterAddAmount=Math.max(100,waterAddAmount-50);showPage("water_add");});
            bindIn(root, R.id.amount_plus, () -> {waterAddAmount=Math.min(1500,waterAddAmount+50);showPage("water_add");});
            bindIn(root, R.id.action_primary, () -> {waterMl=Math.min(3500,waterMl+waterAddAmount);showPage(waterMl>=2500?"water_goal":"water");});
        } else if (page.equals("water_goal")) { bindIn(root,R.id.action_primary,()->showPage("water_history")); bindIn(root,R.id.action_secondary,()->showPage("water_add"));
        } else if (page.equals("water_reminders")) {
            android.widget.Switch sw = root.findViewById(R.id.reminder_switch); if (sw != null) sw.setChecked(remindersOn);
            bindIn(root, R.id.action_primary, () -> {remindersOn=sw != null && sw.isChecked();Toast.makeText(this,"Configurações salvas.",Toast.LENGTH_SHORT).show();showPage("water");});
        } else if (page.equals("workouts")) {
            int[] ids={R.id.train_a,R.id.train_b,R.id.train_c,R.id.train_d};
            for(int i=0;i<ids.length;i++){final int ix=i;bindIn(root,ids[i],()->{selectedWorkout=ix;showPage("workout_detail");});}
        } else if (page.equals("workout_detail")) {
            TextView head=root.findViewById(R.id.workout_heading);
            String[] split={"Peito, ombros e tríceps","Costas, bíceps e abdômen","Membros inferiores e glúteos","Cardio, Abdominais & Funcional"};if(head!=null)head.setText(split[selectedWorkout]);
            for(int i=0;i<4;i++){TextView ex=root.findViewById(new int[]{R.id.exercise_0,R.id.exercise_1,R.id.exercise_2,R.id.exercise_3}[i]);if(ex!=null)ex.setText(String.format(Locale.forLanguageTag("pt-BR"),"◉   %s                                      %dx%d",exercises[selectedWorkout][i],exerciseSets(selectedWorkout,i),exerciseReps(selectedWorkout,i)));}
            bindIn(root,R.id.action_primary,()->{exerciseIndex=0;seriesIndex=0;showPage("workout_run");});
        } else if (page.equals("workout_run")) {
            TextView title=root.findViewById(R.id.run_title), counter=root.findViewById(R.id.run_counter), name=root.findViewById(R.id.run_exercise),meta=root.findViewById(R.id.run_meta),next=root.findViewById(R.id.next_exercise);
            if(title!=null)title.setText("Treino "+"ABCD".charAt(selectedWorkout)+"                                      "+((exerciseIndex*4+seriesIndex+1)*100/16)+"%");
            if(counter!=null)counter.setText("Série "+(seriesIndex+1)+" de "+exerciseSets(selectedWorkout,exerciseIndex));if(name!=null)name.setText(exercises[selectedWorkout][exerciseIndex]);if(meta!=null)meta.setText(exerciseSets(selectedWorkout,exerciseIndex)+" séries · "+exerciseReps(selectedWorkout,exerciseIndex)+" reps");if(next!=null)next.setText(String.format(Locale.forLanguageTag("pt-BR"),"02   %s",exercises[selectedWorkout][Math.min(3,exerciseIndex+1)])); android.widget.ProgressBar runProgress=root.findViewById(R.id.run_progress);if(runProgress!=null){runProgress.setMax(16);runProgress.setProgress(exerciseIndex*4+seriesIndex+1);}int[] setIds={R.id.run_set_1,R.id.run_set_2,R.id.run_set_3,R.id.run_set_4};for(int i=0;i<setIds.length;i++){TextView set=root.findViewById(setIds[i]);if(set!=null){set.setText("Série "+(i+1)+" ("+exerciseReps(selectedWorkout,exerciseIndex)+" reps)"+(i<seriesIndex?"                                 ✓":i==seriesIndex?"                                 ◉":"                                 ○"));set.setTextColor(getColor(i==seriesIndex?R.color.uni_green:R.color.uni_ink));}}TextView nextButton=root.findViewById(R.id.action_primary);if(nextButton!=null)nextButton.setText(seriesIndex+1<exerciseSets(selectedWorkout,exerciseIndex)?"Concluir série":exerciseIndex<3?"Próximo exercício":"Concluir treino");
            bindIn(root,R.id.action_primary,()->{if(seriesIndex+1<exerciseSets(selectedWorkout,exerciseIndex)){seriesIndex++;showPage("workout_run");}else if(exerciseIndex<3){exerciseIndex++;seriesIndex=0;showPage("workout_run");}else showPage("workout_done");});
        } else if (page.equals("workout_done")) { bindIn(root,R.id.action_primary,()->showPage("workouts"));bindIn(root,R.id.action_secondary,this::showHome);
        } else if (page.equals("classes")) {
            bindIn(root,R.id.btn_class_list,()->showPage("class_list"));bindIn(root,R.id.btn_my_classes,()->showPage("my_classes"));bindIn(root,R.id.class_pilates,()->{selectedClass="Pilates";showPage("class_detail");});bindIn(root,R.id.class_functional,()->{selectedClass="Funcional";showPage("class_detail");});
        } else if (page.equals("class_list")) {
            bindIn(root,R.id.class_pilates,()->{selectedClass="Pilates";showPage("class_detail");});bindIn(root,R.id.class_functional,()->{selectedClass="Funcional";showPage("class_detail");});bindIn(root,R.id.class_boxe,()->{selectedClass="Boxe";showPage("class_full");});bindIn(root,R.id.class_yoga,()->{selectedClass="Yoga";showPage("class_detail");});bindIn(root,R.id.class_maya,()->{selectedClass="Maya Thai";showPage("class_detail");});
        } else if (page.equals("class_detail")) {TextView classTitle=root.findViewById(R.id.class_heading);if(classTitle!=null)classTitle.setText(selectedClass);bindIn(root,R.id.action_primary,()->showPage("class_confirm"));
        } else if (page.equals("class_confirm")) {TextView result=root.findViewById(R.id.class_result_name);if(result!=null)result.setText(selectedClass);bindIn(root,R.id.action_primary,()->showPage("my_classes"));bindIn(root,R.id.action_secondary,()->showPage("class_list"));
        } else if (page.equals("class_full")) {TextView result=root.findViewById(R.id.full_class_name);if(result!=null)result.setText(selectedClass);bindIn(root,R.id.action_primary,()->showPage("class_list"));
        } else if (page.equals("my_classes")) {bindIn(root,R.id.enroll_pilates,()->showPage("class_enrollment"));bindIn(root,R.id.enroll_yoga,()->showPage("class_enrollment"));bindIn(root,R.id.enroll_functional,()->showPage("class_enrollment"));
        } else if (page.equals("class_enrollment")) {bindIn(root,R.id.action_primary,()->showPage("my_classes"));
        } else if (page.equals("profile")) {bindIn(root,R.id.btn_personal,()->showPage("personal"));bindIn(root,R.id.btn_settings,()->showPage("settings"));bindIn(root,R.id.btn_logout,this::showLogin);
        } else if (page.equals("personal")) {
            TextView name=root.findViewById(R.id.personal_name),email=root.findViewById(R.id.personal_email);if(name!=null)name.setText(profileName);if(email!=null)email.setText(profileEmail);
            bindIn(root,R.id.action_primary,()->showPage("edit_personal"));
        } else if (page.equals("edit_personal")) {
            EditText name=root.findViewById(R.id.edit_name),email=root.findViewById(R.id.edit_email);
            bindIn(root,R.id.action_primary,()->{if(name!=null)profileName=name.getText().toString();if(email!=null)profileEmail=email.getText().toString();showPage("personal");});bindIn(root,R.id.action_secondary,()->showPage("personal"));
        } else if (page.equals("settings")) {bindIn(root,R.id.btn_privacy,()->showPage("privacy"));bindIn(root,R.id.btn_about,()->showPage("about"));}
    }

    private void bindIn(View root, int id, Runnable action) { View v=root.findViewById(id); if(v!=null)v.setOnClickListener(view->action.run()); }
    private void showPage(String page) { showModule(page); }
    private void highlightNavigation(String page) {
        int active=page.startsWith("water")?R.id.nav_hydration:page.startsWith("workout")?R.id.nav_workouts:(page.startsWith("class")||page.equals("my_classes"))?R.id.nav_agenda:page.equals("profile")||page.equals("personal")||page.equals("edit_personal")||page.equals("settings")||page.equals("privacy")||page.equals("about")?R.id.nav_profile:R.id.nav_home;
        for(int id:new int[]{R.id.nav_home,R.id.nav_agenda,R.id.nav_workouts,R.id.nav_hydration,R.id.nav_profile}){View item=findViewById(id);if(item==null)continue;for(int i=0;i<((android.view.ViewGroup)item).getChildCount();i++){View child=((android.view.ViewGroup)item).getChildAt(i);if(child instanceof android.widget.ImageView)((android.widget.ImageView)child).setColorFilter(getColor(id==active?R.color.module_green:R.color.module_muted));if(child instanceof TextView)((TextView)child).setTextColor(getColor(id==active?R.color.module_green:R.color.module_muted));}}
    }
    private void bind(int id, Runnable action) {
        View view = findViewById(id);
        if (view != null) view.setOnClickListener(v -> action.run());
    }

    private String normalize(String value) {
        return value == null ? "" : value.trim().toLowerCase(Locale.ROOT);
    }

    @Override public void onBackPressed() {
        if (currentScreen.equals("notification_detail") || currentScreen.equals("maintenance")) showNotifications();
        else if (currentScreen.equals("notifications")) showHome();
        else if (currentScreen.equals("home")) super.onBackPressed();
        else if (currentScreen.equals("water")) showHome();
        else if (currentScreen.startsWith("water")) showPage("water");
        else if (currentScreen.equals("workouts")) showHome();
        else if (currentScreen.startsWith("workout")) showPage("workouts");
        else if (currentScreen.equals("classes")) showHome();
        else if (currentScreen.startsWith("class") || currentScreen.equals("my_classes")) showPage("classes");
        else if (currentScreen.equals("profile")) showHome();
        else if (currentScreen.equals("personal") || currentScreen.equals("settings") || currentScreen.equals("privacy") || currentScreen.equals("about") || currentScreen.equals("edit_personal")) showPage("profile");
        else if (!"login".equals(currentScreen)) showLogin();
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (isFinishing() && !isChangingConfigurations()) accountsByEmail.clear();
        super.onDestroy();
    }
}



